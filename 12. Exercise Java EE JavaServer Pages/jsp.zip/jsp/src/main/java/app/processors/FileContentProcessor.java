package app.processors;

public interface FileContentProcessor {

    String readFile(String filePath);
}
