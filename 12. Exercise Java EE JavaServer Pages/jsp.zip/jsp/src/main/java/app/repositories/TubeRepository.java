package app.repositories;

import app.entities.Tube;

public interface TubeRepository extends GenericRepository<Tube> {

}
