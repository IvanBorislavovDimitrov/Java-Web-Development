package app.constants;

public class Constants {

    public static final String PERSISTENCE_UNIT = "exam";

    public static final String LOGGED_USER = "logged_user";
}
