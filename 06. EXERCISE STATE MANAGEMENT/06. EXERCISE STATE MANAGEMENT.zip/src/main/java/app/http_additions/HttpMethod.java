package app.http_additions;

public enum HttpMethod {
	GET, POST
}
