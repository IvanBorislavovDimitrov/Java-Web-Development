package app.constants;

public class Constants {

    public static final String PERSISTENCE_UNIT = "cats_homework";
}
