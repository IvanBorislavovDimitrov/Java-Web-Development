package app.repostitories;

import app.entities.Cat;

public interface CatRepository extends GenericRepository <Cat> {

}
